import User from "../models/user.model.js";
import jwt from "jsonwebtoken";

export const protectPath = async (req, res, next) => {
	try {
		const token = req.cookies.token;
		// const token = req.cookies["token"];
		// const token = req.headers['authorization']?.split(' ')[1];		// return res.status(200).json({ token });
		if (!token) {
			return res.status(401).json({ error: "Unauthorized: No Token Provided" });
		}

		const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

		if (!decoded) {
			return res.status(401).json({ error: "Unauthorized: Invalid Token" });
		}

		const user = await User.findById(decoded.userId).select("-password");
		// const user = await User.findById(decoded.userId);

		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}

		req.user = user;
		next();
	} catch (err) {
		console.log("Error in protectRoute middleware", err.message);
		return res.status(500).json({ error: "Internal Server Error" });
	}
};