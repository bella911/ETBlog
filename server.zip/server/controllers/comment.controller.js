import Comment from '../models/comment.model.js';

export const createComment = async (req, res, next) => {
  try {
    const { content, postId, userId } = req.body;
    // const { content } = req.body;
    // const postId = req.params.id;
    // const userId = req.user.userId;

    if (!content) 
        return res.status(400).json({ error: "content field is required" });

    const newComment = new Comment({
      content,
      postId,
      userId,
    });
    await newComment.save();

    res.status(200).json(newComment);

  } catch (error) {
    console.log("Error in commentOnPost controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getPostComments = async (req, res, next) => {
  try {
    const comments = await Comment.find({ postId: req.params.postId }).sort({
      createdAt: -1,
    });
    res.status(200).json(comments);
  } catch (error) {
    console.log("Error in get post comments controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const likeComment = async (req, res, next) => {
  try {
    const comment = await Comment.findById(req.params.commentId);
    if (!comment) {
      return res.status(404).json("Comment not found");
    }
    const userIndex = comment.likes.indexOf(req.user.userId);
    if (userIndex === -1) {
      comment.numberOfLikes += 1;
      comment.likes.push(req.user.userId);
    } else {
      comment.numberOfLikes -= 1;
      comment.likes.splice(userIndex, 1);
    }
    await comment.save();
    res.status(200).json(comment);
  } catch (error) {
    console.log("Error in like comment controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const editComment = async (req, res, next) => {
  try {
    const comment = await Comment.findById(req.params.commentId);
    if (!comment) {
      return res.status(404).json("Comment not found");
    }
    if (comment.userId !== req.user.userId ) {
      return res.status(403).json("You are not allowed to edit this comment");
    }

    const editedComment = await Comment.findByIdAndUpdate(
      req.params.commentId,
      {
        content: req.body.content,
      },
      { new: true }
    );
    res.status(200).json(editedComment);
  } catch (error) {
    console.log("Error in edit comment controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const deleteComment = async (req, res, next) => {
  try {
    const comment = await Comment.findById(req.params.commentId);
    if (!comment) {
        return res.status(404).json("Comment not found");
    }
    if (comment.userId !== req.user.userId) {
        return res.status(403).json("You are not allowed to edit this comment");
    }
    await Comment.findByIdAndDelete(req.params.commentId);
    res.status(200).json('Comment has been deleted');
  } catch (error) {
    console.log("Error in delete comment controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getcomments = async (req, res, next) => {
//   if (!req.user.isAdmin)
//     return res.status(403).json("You are not allowed to get all comments");
  try {
    const startIndex = parseInt(req.query.startIndex) || 0;
    const limit = parseInt(req.query.limit) || 9;
    const sortDirection = req.query.sort === 'desc' ? -1 : 1;
    const comments = await Comment.find()
      .sort({ createdAt: sortDirection })
      .skip(startIndex)
      .limit(limit);
    const totalComments = await Comment.countDocuments();
    const now = new Date();
    const oneMonthAgo = new Date(
      now.getFullYear(),
      now.getMonth() - 1,
      now.getDate()
    );
    const lastMonthComments = await Comment.countDocuments({
      createdAt: { $gte: oneMonthAgo },
    });
    res.status(200).json({ comments, totalComments, lastMonthComments });
  } catch (error) {
    console.log("Error in get comments controller: ", error);
    res.status(500).json({ error: "Internal server error" });
  }
};